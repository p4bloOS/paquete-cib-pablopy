#! /bin/env python3

import time

peliculas = ["La vida de Bryan", "Matrix", "Torrente"]


def instrucciones():
    """Print essencial information about Python modules and packages.
    """
    time.sleep(1)
    print("Un módulo Python es un fichero que contiene código Python")
    time.sleep(1)
    print("Un paquete Python agrupa varios módulos y submódulos.")
    time.sleep(1)
    print("Para que un directorio se trasforme en paquete Python, agrégale un \
__init.py__")
    time.sleep(1)
    print("¡Has difrutado de la segunda versión de este paquete!")
